#pragma once

struct Vector
{
	float x{}, y{}, z{};
};