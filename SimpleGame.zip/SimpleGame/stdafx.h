#pragma once

#include "targetver.h"
#include "Dependencies\glew.h"
#include "Dependencies\freeglut.h"

#include <iostream>
#include <tchar.h>

constexpr int wndSizeX{ 500 };
constexpr int wndSizeY{ 500 };
