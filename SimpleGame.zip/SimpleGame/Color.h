#pragma once

struct Color
{
	float r{}, g{}, b{}, a{};
};